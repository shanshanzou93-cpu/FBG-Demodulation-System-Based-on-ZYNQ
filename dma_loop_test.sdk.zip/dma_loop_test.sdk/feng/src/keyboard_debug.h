/******************************************************************************
*
* Copyright (C) 2010 - 2025 lixiaoyou.  All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
 *  @file keyboard_debug.h Created on: 2025��3��8��    Author: lixiaoyou
 *  @addtogroup LTC2262_v0_1
 *  @{
 *     keyboard debug
 *****************************************************************************/
#ifndef SRC_KEYBOARD_DEBUG_H_
#define SRC_KEYBOARD_DEBUG_H_
/***************************** Include Files *********************************/
#include <stdio.h>
#include "xil_printf.h"
#include "xil_types.h"

/************************** Constant Definitions *****************************/

/************************** Function Prototypes ******************************/
int Keyboard_DaInput5(u16 *DaValue);
int Keyboard_DaInput4(char *Select_Data,u16 *DaValue);
int Keyboard_DaInput3(char *Select_Data,u16 *DaValue);
int Keyboard_DaInput2(char *Select_Data,u16 *DaValue);
int Keyboard_DaInput1(char *Select_Data,u16 *DaValue);
u16 keyboardMode_Select(char *Select_Data);

#endif
/** @}* SRC_KEYBOARD_DEBUG_H_ */
