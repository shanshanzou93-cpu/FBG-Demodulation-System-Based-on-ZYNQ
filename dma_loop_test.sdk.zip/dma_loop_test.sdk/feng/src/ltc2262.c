/******************************************************************************
*
* Copyright (C) 2010 - 2025 lixiaoyou.  All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
 *  @file LTC2262.c  Created on: 2025��3��4��   Author: lixiaoyou
 *  @addtogroup LTC2262_v0_1
 *  @{
 *
 * Hardware definition file. It defines the register interface.
 *
 *****************************************************************************/
#include "ltc2262.h"

/************************** Function Prototypes ******************************/
//u32 Write_DA(u32 Dac,u32 Data);
//u32 Set_Span(u32 Dac,u32 DA_Span);

/************************** Variable Definitions *****************************/
static  XGpioPs  EMIO;                //XGpioPs����
static  XGpioPs_Config *EMIO_CfgPtr;  //XGpioPs���ñ�����ָ�루XGpioPs ID������ַ��

/*****************************************************************************/

 void SpiLoad_Config(){
	int Status = 0;
	EMIO_CfgPtr = XGpioPs_LookupConfig(EMIO_ID);
	Status = XGpioPs_CfgInitialize(&EMIO,EMIO_CfgPtr,EMIO_CfgPtr->BaseAddr);
	if(Status ==  XST_FAILURE){
	   	xil_printf("EMIO configure initialize failure");
	}
	XGpioPs_SetDirectionPin(&EMIO,LOAD_DAC,1);         // LOAD_DAC����Ϊ������ţ�0Ϊ���룬1Ϊ���
	XGpioPs_SetOutputEnablePin(&EMIO,LOAD_DAC,1);      // LOAD_DAC���ʹ�ܣ�1Ϊʹ�ܣ�0Ϊ��ֹ
	XGpioPs_WritePin(&EMIO,LOAD_DAC, 1);               // LOAD_DAC���,1Ϊ�����0Ϊ��ֹ
}
void SetDacLoad(){
	XGpioPs_WritePin(&EMIO,LOAD_DAC, 0);  //Spi DAC load���,1Ϊ�����0Ϊ��ֹ
}

u32 Write_Dac(u32 Dac,u16 Data){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_DA + Dac + (u32)Data;
	return WriteDaCommand;
}

u32 Set_Soa(u32 SoaCurrent){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_SOA + SoaCurrent;
	return WriteDaCommand;
}
u32 Set_Gain(u32 GainCurrent){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_GAIN + GainCurrent;
	return WriteDaCommand;
}
u32 Set_Phase(u32 PhaseCurrent){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_PHASE + PhaseCurrent;
	return WriteDaCommand;
}
u32 Set_Left(u32 LeftCurrent){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_LEFT + LeftCurrent;
	return WriteDaCommand;
}
u32 Set_Right(u32 RightCurrent){
	u32 WriteDaCommand;
	WriteDaCommand = WRITE_RIGHT + RightCurrent;
	return WriteDaCommand;
}

u32 Set_DacSpan(u32 Dac,u32 DA_Span){
	u32 SetSpanCommand;
	SetSpanCommand = SET_SPAN + Dac + DA_Span;
	return SetSpanCommand;
}
/** @} */

