#include <stdio.h>
#include <stdint.h>

#include "platform.h"
#include "xparameters.h"
#include "xil_printf.h"
#include "xil_io.h"
#include "xil_cache.h"

#include "xaxidma.h"
#include "xscugic.h"

#include "dma_intr.h"
#include "sys_intr.h"
#include "ltc2262.h"
#include "laser_scan_data.h"


// ============================================================================
// HLS IP �Ĵ�����ַ�����������ɵ� xgauss_fit_demod_multi_axilites.h �޸ģ�
// ============================================================================
#define BASEADDRESS              0x43C00000U

#define REG_AP_CTRL              (BASEADDRESS + 0x00U)
#define REG_LAMBDA_START         (BASEADDRESS + 0x10U)
#define REG_LAMBDA_STEP          (BASEADDRESS + 0x18U)
#define REG_DATA_LEN             (BASEADDRESS + 0x20U)
#define REG_MAX_PEAKS            (BASEADDRESS + 0x28U)   // ������������
#define REG_THRESH_RATIO         (BASEADDRESS + 0x30U)
#define REG_MIN_PEAK_DISTANCE    (BASEADDRESS + 0x38U)   // ��������С���
#define REG_BASE_EDGE            (BASEADDRESS + 0x40U)


// ============================================================================
// DMA�豸
// ============================================================================
static XAxiDma AxiDma;          // DA/AD DMA
static XAxiDma AxiDmaStream;    // HLS AXI-Stream DMA
static XScuGic Intc;

static u32 *TxBufferPtr = (u32 *)TX_BUFFER_BASE;
static u32 *RxBufferPtr = (u32 *)RX_BUFFER_BASE;


// ============================================================================
// ϵͳ����
// ============================================================================
#define MAX_PKT_LEN              20U            // 5�������� = 20 �ֽ�
#define MAX_PKT_LEN2             8U             // 2��32λ�� = 8 �ֽ�

#define SCAN_DATA_LEN            2126
#define POINTS                   6              // ����������Ӧ HLS �� max_peaks��

#define LAMBDA_START             1528.0f
#define LAMBDA_STEP              0.008f

#define THRESH_RATIO             0.25f          // ��ֵ�����ֵ����
#define MIN_PEAK_DISTANCE        50             // ��С��ࣨ���أ�
#define BASELINE_EDGE            20             // ���߹��Ʊ�Ե����

#define DISCARD_SCANS            1              // ������ɨ�����
#define AVERAGE_SCANS            1              // ƽ����ɨ�����

// HLS�����������С��1������ + ÿ����2��float
#define MAX_OUT_FLOATS           (1 + 2 * POINTS)


// ============================================================================
// ȫ�ֻ�����
// ============================================================================
static s16 ad1_raw[SCAN_DATA_LEN];            // �洢ƽ�����ADֵ�����������
static float spectrum_float[SCAN_DATA_LEN]    // ���ף�����HLS��
    __attribute__((aligned(64)));

static float spectrum_sum[SCAN_DATA_LEN];      // �ۼӻ��壨���ڶ��ƽ����
static float result_buf[MAX_OUT_FLOATS]       // HLS������
    __attribute__((aligned(64)));


// ============================================================================
// ��������
// ============================================================================
static void configure_hls_ip(void);

static int configure_dac_range(void);
static int write_dac_scan_point(int scan_index);
static int read_adc_once(s16 *sample);

static int acquire_one_spectrum(int save_raw);
static int run_hls_demodulation(void);

static void print_wavelength(float nm);


// ============================================================================
// ������
// ============================================================================
int main(void)
{
    int Status;

    init_platform();

    //xil_printf("\r\n========================================\r\n");
    //xil_printf("FBG Demodulation (Discard 1, Average 8)\r\n");
    //xil_printf("========================================\r\n\r\n");


    // ========================================================================
    // 1. DA/AD DMA��ʼ��
    // ========================================================================
    Status = DMA_Intr_Init(&AxiDma, 0);
    if (Status != XST_SUCCESS) {
        xil_printf("DA/AD DMA initialization failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }

    Status = Init_Intr_System(&Intc);
    if (Status != XST_SUCCESS) {
        xil_printf("Interrupt controller initialization failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }

    Setup_Intr_Exception(&Intc);

    Status = DMA_Setup_Intr_System(&Intc, &AxiDma, TX_INTR_ID, RX_INTR_ID);
    if (Status != XST_SUCCESS) {
        xil_printf("DA/AD DMA interrupt setup failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }

    DMA_Intr_Enable(&Intc, &AxiDma);


    // ========================================================================
    // 2. HLS Stream DMA��ʼ��
    // ========================================================================
#define DMA_STREAM_DEV_ID    XPAR_AXIDMA_1_DEVICE_ID

    XAxiDma_Config *cfg_stream = XAxiDma_LookupConfig(DMA_STREAM_DEV_ID);
    if (cfg_stream == NULL) {
        xil_printf("HLS Stream DMA configuration not found\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }

    Status = XAxiDma_CfgInitialize(&AxiDmaStream, cfg_stream);
    if (Status != XST_SUCCESS) {
        xil_printf("HLS Stream DMA initialization failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }

    // HLS DMAʹ����ѯ��ʽ
    XAxiDma_IntrDisable(&AxiDmaStream, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DEVICE_TO_DMA);
    XAxiDma_IntrDisable(&AxiDmaStream, XAXIDMA_IRQ_ALL_MASK, XAXIDMA_DMA_TO_DEVICE);


    // ========================================================================
    // 3. DA��������
    // ========================================================================
    Status = configure_dac_range();
    if (Status != XST_SUCCESS) {
        xil_printf("DAC range configuration failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }


    // ========================================================================
    // 4. ����HLS������������IP��
    // ========================================================================
    configure_hls_ip();


    // ========================================================================
    // 5. �ɼ����ף����� DISCARD_SCANS �Σ�Ȼ��ƽ�� AVERAGE_SCANS ��
    // ========================================================================
    //xil_printf("Starting acquisition (discard %d, average %d)...\r\n",
               //DISCARD_SCANS, AVERAGE_SCANS);

    // ����ǰ����ɨ�裬��ϵͳ�ȶ�
    for (int i = 0; i < DISCARD_SCANS; i++) {
        Status = acquire_one_spectrum(0);   // �����棬���ȶ�ϵͳ
        if (Status != XST_SUCCESS) {
            xil_printf("Discard scan %d failed\r\n", i);
            cleanup_platform();
            return XST_FAILURE;
        }
    }

    // �ۼӶ��ɨ��
    for (int i = 0; i < SCAN_DATA_LEN; i++) {
        spectrum_sum[i] = 0.0f;             // �����ۼӻ���
    }

    for (int avg = 0; avg < AVERAGE_SCANS; avg++) {
        Status = acquire_one_spectrum(0);   // ������ԭʼ��������� spectrum_float
        if (Status != XST_SUCCESS) {
            //xil_printf("Average scan %d failed\r\n", avg);
            cleanup_platform();
            return XST_FAILURE;
        }
        for (int i = 0; i < SCAN_DATA_LEN; i++) {
            spectrum_sum[i] += spectrum_float[i];
        }
    }

    // ����ƽ��ֵ��ͬʱ��������AD�������
    for (int i = 0; i < SCAN_DATA_LEN; i++) {
        spectrum_float[i] = spectrum_sum[i] / (float)AVERAGE_SCANS;
        ad1_raw[i] = (s16)(spectrum_float[i] + 0.5f);  // ��������
    }

    // ========================================================================
    // 6. ִ��HLS���
    // ========================================================================
    Status = run_hls_demodulation();
    if (Status != XST_SUCCESS) {
        xil_printf("Demodulation failed\r\n");
        cleanup_platform();
        return XST_FAILURE;
    }


    // ========================================================================
    // 7. ���ȫ��ADֵ��ƽ��������������
    // ========================================================================
    //xil_printf("=== All AD Values (averaged) ===\r\n");
    for (int i = 0; i < SCAN_DATA_LEN; i++) {
        xil_printf("%d\r\n", ad1_raw[i]);
    }


    // ========================================================================
    // 8. ���������
    // ========================================================================
    int num_peaks = (int)result_buf[0];
    if (num_peaks > POINTS) num_peaks = POINTS;

    xil_printf("=== Demodulation Result ===\r\n");
    for (int p = 0; p < num_peaks; p++) {
        float pix_idx_f = result_buf[1 + 2 * p];
        float wavelength = result_buf[1 + 2 * p + 1];
        int pix_idx = (int)(pix_idx_f + 0.5f);
        xil_printf("%d ", pix_idx);
        print_wavelength(wavelength);
        xil_printf("\r\n");
    }

    //xil_printf("===========================\r\n");
    cleanup_platform();
    return XST_SUCCESS;
}


// ============================================================================
// ����DA�������
// ============================================================================
static int configure_dac_range(void)
{
    int Status;

    SpiLoad_Config();
    SetDacLoad();

    TxBufferPtr[0] = Set_DacSpan(DAC0, SPAN_200mA);
    TxBufferPtr[1] = Set_DacSpan(DAC1, SPAN_100mA);
    TxBufferPtr[2] = Set_DacSpan(DAC2, SPAN_12mA5);
    TxBufferPtr[3] = Set_DacSpan(DAC3, SPAN_50mA);
    TxBufferPtr[4] = Set_DacSpan(DAC4, SPAN_50mA);

    Xil_DCacheFlushRange((u32)TxBufferPtr, MAX_PKT_LEN);

    TxDone = 0; RxDone = 0; Error = 0;

    Status = XAxiDma_SimpleTransfer(&AxiDma, (u32)TxBufferPtr, MAX_PKT_LEN, XAXIDMA_DMA_TO_DEVICE);
    if (Status != XST_SUCCESS) return XST_FAILURE;

    Status = XAxiDma_SimpleTransfer(&AxiDma, (u32)RxBufferPtr, MAX_PKT_LEN2, XAXIDMA_DEVICE_TO_DMA);
    if (Status != XST_SUCCESS) return XST_FAILURE;

    while ((!TxDone || !RxDone) && !Error) {}
    if (Error) return XST_FAILURE;

    TxDone = 0; RxDone = 0;
    Xil_DCacheInvalidateRange((u32)RxBufferPtr, MAX_PKT_LEN2);
    return XST_SUCCESS;
}


// ============================================================================
// ����һ������ɨ����Ӧ��5·DAC
// ============================================================================
static int write_dac_scan_point(int scan_index)
{
    int Status;

    u16 dac_data[5] = {
        Laser_Scan_Data[scan_index][0],
        Laser_Scan_Data[scan_index][1],
        Laser_Scan_Data[scan_index][2],
        Laser_Scan_Data[scan_index][3],
        Laser_Scan_Data[scan_index][4]
    };

    if (dac_data[2] > PHASE_MAX) dac_data[2] = PHASE_MAX;
    if (dac_data[0] > SOA_MAX)   dac_data[0] = SOA_MAX;
    if (dac_data[1] > GAIN_MAX)  dac_data[1] = GAIN_MAX;
    if (dac_data[3] > LEFT_MAX)  dac_data[3] = LEFT_MAX;
    if (dac_data[4] > RIGHT_MAX) dac_data[4] = RIGHT_MAX;

    TxBufferPtr[0] = Write_Dac(DAC0, dac_data[0]);
    TxBufferPtr[1] = Write_Dac(DAC1, dac_data[1]);
    TxBufferPtr[2] = Write_Dac(DAC2, dac_data[2]);
    TxBufferPtr[3] = Write_Dac(DAC3, dac_data[3]);
    TxBufferPtr[4] = Write_Dac(DAC4, dac_data[4]);

    Xil_DCacheFlushRange((u32)TxBufferPtr, MAX_PKT_LEN);

    TxDone = 0; Error = 0;

    Status = XAxiDma_SimpleTransfer(&AxiDma, (u32)TxBufferPtr, MAX_PKT_LEN, XAXIDMA_DMA_TO_DEVICE);
    if (Status != XST_SUCCESS) return XST_FAILURE;

    while (!TxDone && !Error) {}
    if (Error) return XST_FAILURE;

    TxDone = 0;
    return XST_SUCCESS;
}


// ============================================================================
// ���һ��AD����������һ������2��32λ�ֵİ���
// ============================================================================
static int read_adc_once(s16 *sample)
{
    int Status;

    if (sample == NULL) return XST_FAILURE;

    RxDone = 0; Error = 0;

    Status = XAxiDma_SimpleTransfer(&AxiDma, (u32)RxBufferPtr, MAX_PKT_LEN2, XAXIDMA_DEVICE_TO_DMA);
    if (Status != XST_SUCCESS) return XST_FAILURE;

    while (!RxDone && !Error) {}
    if (Error) return XST_FAILURE;

    RxDone = 0;
    Xil_DCacheInvalidateRange((u32)RxBufferPtr, MAX_PKT_LEN2);

    u16 adc_raw = (u16)(RxBufferPtr[0] & 0xFFFFU);
    *sample = (s16)adc_raw - 13;

    return XST_SUCCESS;
}


// ============================================================================
// ���һ����������ɨ��
// ���� save_raw : ��0ʱ�����ȡ����ADֵ�� ad1_raw ����
// ע�⣺���� save_raw Ϊ��ֵ��������� spectrum_float ����
// ============================================================================
static int acquire_one_spectrum(int save_raw)
{
    int Status;

    for (int scan_index = 0; scan_index < SCAN_DATA_LEN; scan_index++) {

        Status = write_dac_scan_point(scan_index);
        if (Status != XST_SUCCESS) {
            xil_printf("DAC update failed at point %d\r\n", scan_index);
            return XST_FAILURE;
        }

        s16 adc_sample = 0;
        Status = read_adc_once(&adc_sample);
        if (Status != XST_SUCCESS) {
            xil_printf("ADC read failed at point %d\r\n", scan_index);
            return XST_FAILURE;
        }

        if (save_raw) {
            ad1_raw[scan_index] = adc_sample;
        }
        spectrum_float[scan_index] = (float)adc_sample;
    }

    return XST_SUCCESS;
}


// ============================================================================
// ִ��һ��HLS���
// ============================================================================
static int run_hls_demodulation(void)
{
    int Status;

    for (int i = 0; i < MAX_OUT_FLOATS; i++) {
        result_buf[i] = -9999.0f;
    }
    Xil_DCacheFlushRange((u32)result_buf, MAX_OUT_FLOATS * sizeof(float));

    Xil_DCacheFlushRange((u32)spectrum_float, SCAN_DATA_LEN * sizeof(float));

    Status = XAxiDma_SimpleTransfer(&AxiDmaStream, (u32)result_buf,
                                    MAX_OUT_FLOATS * sizeof(float), XAXIDMA_DEVICE_TO_DMA);
    if (Status != XST_SUCCESS) {
        xil_printf("HLS S2MM DMA start failed\r\n");
        return XST_FAILURE;
    }

    Xil_Out32(REG_AP_CTRL, 0x01U);

    Status = XAxiDma_SimpleTransfer(&AxiDmaStream, (u32)spectrum_float,
                                    SCAN_DATA_LEN * sizeof(float), XAXIDMA_DMA_TO_DEVICE);
    if (Status != XST_SUCCESS) {
        xil_printf("HLS MM2S DMA start failed\r\n");
        return XST_FAILURE;
    }

    while (XAxiDma_Busy(&AxiDmaStream, XAXIDMA_DMA_TO_DEVICE) ||
           XAxiDma_Busy(&AxiDmaStream, XAXIDMA_DEVICE_TO_DMA)) {}

    Xil_DCacheInvalidateRange((u32)result_buf, MAX_OUT_FLOATS * sizeof(float));

    return XST_SUCCESS;
}


// ============================================================================
// ����HLS IP��������������
// ============================================================================
static void configure_hls_ip(void)
{
    union { float f; uint32_t u; } val;

    val.f = LAMBDA_START;
    Xil_Out32(REG_LAMBDA_START, val.u);

    val.f = LAMBDA_STEP;
    Xil_Out32(REG_LAMBDA_STEP, val.u);

    Xil_Out32(REG_DATA_LEN, SCAN_DATA_LEN);

    Xil_Out32(REG_MAX_PEAKS, POINTS);

    val.f = THRESH_RATIO;
    Xil_Out32(REG_THRESH_RATIO, val.u);

    Xil_Out32(REG_MIN_PEAK_DISTANCE, MIN_PEAK_DISTANCE);

    Xil_Out32(REG_BASE_EDGE, BASELINE_EDGE);
}


// ============================================================================
// ��ȫ��ӡ������������4λС����
// ============================================================================
static void print_wavelength(float nm)
{
    int wl_int = (int)nm;
    int wl_frac = (int)((nm - wl_int) * 10000.0f + 0.5f);
    if (wl_frac < 0) { wl_int--; wl_frac += 10000; }
    xil_printf("%d.%04d", wl_int, wl_frac);
}

