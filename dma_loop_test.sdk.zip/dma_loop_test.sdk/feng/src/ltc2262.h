/******************************************************************************
*
* Copyright (C) 2010 - 2025 lixiaoyou.  All rights reserved.
*
******************************************************************************/
/*****************************************************************************/
/**
 *  @file LTC2262.h Created on: 2025��3��4��    Author: lixiaoyou
 *  @addtogroup LTC2262_v0_1
 *  @{
 *
 * Hardware definition file. It defines the register interface.
 *
 *****************************************************************************/
#ifndef SRC_LTC2262_H_
#define SRC_LTC2262_H_

/***************************** Include Files *********************************/
#include "xil_types.h"
#include "xil_printf.h"
#include "xgpiops.h"
#include "xgpiops_hw.h"

#define EMIO_ID  XPAR_PS7_GPIO_0_DEVICE_ID       //EMIO������54-85bank2��86-117bank3
#define LOAD_DAC 54                              //output��  spi dac load

/************************** Constant Definitions *****************************/
/** @name LTC2262 Command Codes
 *  @{ 32bit Spi data mode
 *     D[31:24]    D[23:20]      D[19:16]      D[15:0]
 *        xx        C[3:0]        A[3:0]        D[15:0]
 *     no care   command code  DAC address  operation data
 */
#define DA_WRITE_N             0x0     //Write Code to n,n=DA address
#define DA_WRITE_ALL           0x8     //Write Code to All
#define SPAN_WRITE_N           0x6     //Write Span to n,n=DA address
#define SPAN_WRITE_ALL         0xE     //Write Span to All

#define UPDATE_DA_N            0x1     //Update n (Power Up),n=DA address
#define UPDATE_DA_ALL          0x9     //Update All (Power Up)
#define DA_WRITE_UPDATE_N      0x3     //Write Code to n, Update n (Power Up)
#define DA_WRITE_N_UPDATE_ALL  0x2     //Write Code to n, Update All (Power Up)
#define DA_WRITE_UPDATE_ALL    0xA     //Write Code to All, Update All (Power Up)

#define POWER_DOWN_N           0x4     //Power Down n,n=DA address
#define POWER_DOWN_CHIP        0x5     //Power Down Chip

#define MONITOR_MUX            0xB     //Monitor Mux
#define TOGGLE_SELECT          0xC     //Toggle Select
#define TOGGLE_ALL             0xD     //Global Toggle
#define CONFIG_COMMAND         0x7     //Config Command
#define NO_OPERATION           0xF     //No Operation
/*@}*/

/** @name LTC2262 DA address
 *  @{ 4bit dac address    D[19:16]  A[3:0]
 */
#define DAC0  0x00000000  // 0x0
#define DAC1  0x00010000  // 0x1
#define DAC2  0x00020000  // 0x2
#define DAC3  0x00030000  // 0x3
#define DAC4  0x00040000  // 0x4
/*@}*/

/** @name LTC2262 Span Data S[3:0]
 *  @{ 32bit command {D[31:24],D[23:20],D[19:16],D[15:0]}=0xFF,6_DA address_FFF_Span Data
 */
#define SPAN_0mA    0x0   // Hi_Z
#define SPAN_3mA    0x1   // 3.125mA
#define SPAN_6mA25  0x2   // 6.25mA
#define SPAN_12mA5  0x3   // 12.5mA
#define SPAN_25mA   0x4   // 25mA
#define SPAN_50mA   0x5   // 50mA
#define SPAN_100mA  0x6   // 100mA
#define SPAN_200mA  0x7   // 200mA
#define SPAN_300mA  0xF   // 300mA
#define SPAN_VN     0x8   // Switch to V�C
/*@}*/

/** @name LTC2262 Monitor Mux Data M[4:0]
 *  @{ 32bit command {D[31:24],D[23:20],D[19:16],D[15:0]}=0xFF,6_DA address_FF7_Mux Data
 */
#define MUX_Z       0x0   //Disabled (Hi-Z)
#define MUX_I0      0x1   //OUT0 Current Measurement I=IFS*VMUX/VREF
#define MUX_I1      0x2   //OUT0 Current Measurement I=IFS*VMUX/VREF
#define MUX_I2      0x3   //OUT0 Current Measurement I=IFS*VMUX/VREF
#define MUX_I3      0x4   //OUT0 Current Measurement I=IFS*VMUX/VREF
#define MUX_I4      0x5   //OUT0 Current Measurement I=IFS*VMUX/VREF
#define MUX_VCC     0x6   //VCC
#define MUX_VREF    0x8   //VREF
#define MUX_VREFLO  0x9   //DAC Reference GND
#define MUX_T       0xA   //Die Temperature, T=25��C+(1.4V �C VMUX)/(0.0037V/��C)
#define MUX_VDD0    0x10  //VDD0
#define MUX_VDD1    0x11  //VDD1
#define MUX_VDD2    0x12  //VDD2
#define MUX_VDD3    0x13  //VDD3
#define MUX_VDD4    0x14  //VDD4
#define MUX_VP      0x15  //V+
#define MUX_VN      0x16  //V-
#define MUX_GND     0x17  //GND
#define MUX_VOUT0   0x18  //OUT0 Pin Voltage
#define MUX_VOUT1   0x19  //OUT1 Pin Voltage
#define MUX_VOUT2   0x1A  //OUT2 Pin Voltage
#define MUX_VOUT3   0x1B  //OUT3 Pin Voltage
#define MUX_VOUT4   0x1C  //OUT4 Pin Voltage
/*@}*/

/** @name LTC2262 Monitor Configure Data Configure Bit[OC,PL,TS,RD]
 *  @{ 32bit command {D[31:24],D[23:20],D[19:16],D[15:0]}=0xFF,6_DA address_FFF_Config Data
 */
#define CONFIG_OC   0b1000  //OCλ���ÿ�·��⣨FR0��FR4��
#define CONFIG_PL   0b0100  //PLλ���ù������Ʊ�����FR6��
#define CONFIG_TS   0b0010  //TSλ���ù��ȱ�����FR5��
#define CONFIG_RD   0b0001  //RDλ����ѡ���ⲿ��׼
/*@}*/

/** @name LTC2262 Operation Command
 *  @{ 32bit Spi data mode  D[31:24]    D[23:20]      D[19:16]      D[15:0]
 *                             xx        C[3:0]        A[3:0]        D[15:0]
 *                           no care   command code  DAC address  operation data
 */
#define WRITE_DA   0xFF000000   //0xFF000000Write DAC  0xFF300000Data Write Code to n, Update n (Power Up)

#define WRITE_SOA    0xFF000000
#define WRITE_GAIN   0xFF010000
#define WRITE_PHASE  0xFF020000
#define WRITE_LEFT   0xFF030000
#define WRITE_RIGHT  0xFF040000

#define SET_SPAN     0xFF60FFF0 //Write DAC Span Code

#define SPAN_SOA   0xFF61FFF7  //Out0 soa   max 240mA norm 167mA  span 200mA
#define SPAN_GAIN  0xFF62FFF6  //Out1 gain  max 160mA norm 100mA  span 100mA
#define SPAN_PHASE 0xFF63FFF3  //Out2 phase max 10mA  norm 7.5mA  span 12.5mA
#define SPAN_LEFT  0xFF64FFF5  //OUt3 left  max 50mA  norm 35mA   span 50mA
#define SPAN_RIGHT 0xFF64FFF5  //OUt4 right max 50mA  norm 35mA   span 50mA

/*@}*/

/************************** Function Prototypes ******************************/

/*
 * Initialization and control functions in LTC2262.c *
 */
void SpiLoad_Config();
void SetDacLoad();// XGpioPs_WritePin(&EMIO,LOAD_DAC, 1)  //Spi DAC load���,1Ϊ�����0Ϊ��ֹ
u32 Write_Dac(u32 Dac,u16 Data);

u32 Set_Soa(u32 SoaCurrent);
u32 Set_Gain(u32 GainCurrent);
u32 Set_Phase(u32 PhaseCurrent);
u32 Set_Left(u32 LeftCurrent);
u32 Set_Right(u32 RightCurrent);

u32 Set_DacSpan(u32 Dac,u32 DA_Span);
#endif
/** @} * SRC_LTC2262_H_ */
