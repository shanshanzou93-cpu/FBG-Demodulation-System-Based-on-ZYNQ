#include "gauss_feng.h"
#include <math.h>

#if GAUSS_FAST_LOG
#if GAUSS_LOG_IMPL == 1
static const uint32_t kLog2Packed128[128] = {
    0x000002E0U, 0x02E002DAU, 0x05BA02D5U, 0x088E02CFU, 0x0B5D02CAU, 0x0E2702C4U, 0x10EB02BFU, 0x13AA02BAU,
    0x166402B5U, 0x191902B0U, 0x1BC802ABU, 0x1E7302A6U, 0x211902A1U, 0x23BA029CU, 0x26560298U, 0x28ED0293U,
    0x2B80028EU, 0x2E0F028AU, 0x30980285U, 0x331E0281U, 0x359F027DU, 0x381B0278U, 0x3A940274U, 0x3D080270U,
    0x3F78026CU, 0x41E40268U, 0x444C0264U, 0x46B00260U, 0x4910025CU, 0x4B6C0258U, 0x4DC50255U, 0x50190251U,
    0x526A024DU, 0x54B70249U, 0x57000246U, 0x59460242U, 0x5B89023FU, 0x5DC7023BU, 0x60030238U, 0x623A0234U,
    0x646F0231U, 0x66A0022EU, 0x68CE022BU, 0x6AF80227U, 0x6D200224U, 0x6F440221U, 0x7165021EU, 0x7383021BU,
    0x759D0218U, 0x77B50215U, 0x79CA0212U, 0x7BDB020FU, 0x7DEA020CU, 0x7FF60209U, 0x81FF0206U, 0x84050203U,
    0x86080200U, 0x880901FEU, 0x8A0601FBU, 0x8C0101F8U, 0x8DFA01F6U, 0x8FEF01F3U, 0x91E201F0U, 0x93D201EEU,
    0x95C001EBU, 0x97AB01E9U, 0x999401E6U, 0x9B7A01E4U, 0x9D5E01E1U, 0x9F3F01DFU, 0xA11E01DCU, 0xA2FA01DAU,
    0xA4D401D8U, 0xA6AB01D5U, 0xA88101D3U, 0xAA5301D1U, 0xAC2401CEU, 0xADF201CCU, 0xAFBE01CAU, 0xB18801C8U,
    0xB35001C5U, 0xB51501C3U, 0xB6D901C1U, 0xB89A01BFU, 0xBA5901BDU, 0xBC1601BBU, 0xBDD101B9U, 0xBF8A01B7U,
    0xC14001B5U, 0xC2F501B3U, 0xC4A801B1U, 0xC65801AFU, 0xC80701ADU, 0xC9B401ABU, 0xCB5F01A9U, 0xCD0801A7U,
    0xCEAF01A5U, 0xD05401A3U, 0xD1F701A1U, 0xD39901A0U, 0xD538019EU, 0xD6D6019CU, 0xD872019AU, 0xDA0C0198U,
    0xDBA50197U, 0xDD3B0195U, 0xDED00193U, 0xE0630191U, 0xE1F50190U, 0xE385018EU, 0xE513018CU, 0xE69F018BU,
    0xE82A0189U, 0xE9B30188U, 0xEB3B0186U, 0xECC10184U, 0xEE450183U, 0xEFC80181U, 0xF1490180U, 0xF2C8017EU,
    0xF446017CU, 0xF5C3017BU, 0xF73E0179U, 0xF8B70178U, 0xFA2F0176U, 0xFBA50175U, 0xFD1A0174U, 0xFE8E0172U
};
// V5: segment lookup and linear interpolation are INTEGER-ONLY.
// One read of 128 x 32 packed Q0.16 ROM per call.
// Each entry packs (base_Q16 << 16) | slope_Q16.
// Float conversion happens ONCE after the integer interpolation.
static float fit_log(float positive_normal) {
#pragma HLS INLINE
    union { float f; uint32_t u; } cv;
    cv.f = positive_normal;
    const uint32_t bits = cv.u;
    const int exponent = (int)((bits >> 23) & 255U) - 127;
    const uint32_t fraction = bits & 0x7fffffU;
    const uint32_t segment = fraction >> 16;       // 0..127
    const uint32_t frac16 = fraction & 0xffffU;    // local fraction in Q0.16
    const uint32_t packed = kLog2Packed128[segment];
    const uint32_t bq16 = packed >> 16;
    const uint32_t sq16 = packed & 0xffffU;
    // Small unsigned integer multiply, product < 2^26, no overflow.
    const uint32_t increment = (sq16 * frac16 + 32768U) >> 16;
    const int32_t log_q16 = exponent * 65536 + (int32_t)bq16
                          + (int32_t)increment;
    return (float)log_q16 * (1.0f / 65536.0f);
}

#elif GAUSS_LOG_IMPL == 0
// For positive, NORMAL IEEE-754 float values: log2(x) = exponent + log2(mantissa).
// 128-segment interpolation: max absolute error < 1.1e-5 in log2 units.
// We clamp to >= 1e-9 before calling this function, so subnormals cannot occur.
static const float kLog2Base[128] = {
    0.0f, 0.01122725542f, 0.02236781303f, 0.03342300154f, 0.04439411936f, 0.0552824355f,
    0.06608919046f, 0.07681559705f, 0.08746284125f, 0.09803208296f, 0.1085244568f, 0.1189410727f,
    0.1292830169f, 0.1395513524f, 0.1497471195f, 0.1598713368f, 0.1699250014f, 0.17990909f,
    0.1898245589f, 0.1996723448f, 0.2094533656f, 0.2191685205f, 0.2288186905f, 0.2384047393f,
    0.2479275134f, 0.2573878427f, 0.2667865407f, 0.2761244053f, 0.2854022189f, 0.2946207489f,
    0.3037807482f, 0.3128829553f, 0.3219280949f, 0.3309168781f, 0.3398500029f, 0.3487281542f,
    0.3575520046f, 0.3663222142f, 0.3750394313f, 0.3837042925f, 0.3923174228f, 0.4008794363f,
    0.4093909361f, 0.4178525149f, 0.4262647547f, 0.4346282276f, 0.4429434958f, 0.4512111118f,
    0.4594316186f, 0.4676055501f, 0.475733431f, 0.4838157773f, 0.4918530963f, 0.4998458871f,
    0.5077946402f, 0.5156998383f, 0.5235619561f, 0.5313814605f, 0.5391588111f, 0.5468944599f,
    0.5545888517f, 0.5622424242f, 0.5698556083f, 0.577428828f, 0.5849625007f, 0.5924570373f,
    0.5999128422f, 0.6073303137f, 0.6147098441f, 0.6220518195f, 0.6293566201f, 0.6366246205f,
    0.6438561898f, 0.6510516912f, 0.6582114828f, 0.6653359172f, 0.672425342f, 0.6794800995f,
    0.6865005272f, 0.6934869575f, 0.7004397181f, 0.7073591321f, 0.7142455177f, 0.7210991887f,
    0.7279204546f, 0.7347096202f, 0.7414669864f, 0.7481928496f, 0.7548875022f, 0.7615512324f,
    0.7681843248f, 0.7747870596f, 0.7813597135f, 0.7879025594f, 0.7944158664f, 0.8008998999f,
    0.8073549221f, 0.8137811912f, 0.8201789624f, 0.8265484873f, 0.8328900142f, 0.8392037881f,
    0.8454900509f, 0.8517490414f, 0.8579809951f, 0.8641861447f, 0.8703647196f, 0.8765169466f,
    0.8826430494f, 0.8887432489f, 0.8948177633f, 0.900866808f, 0.9068905956f, 0.9128893362f,
    0.9188632373f, 0.9248125036f, 0.9307373376f, 0.936637939f, 0.9425145053f, 0.9483672316f,
    0.9541963104f, 0.9600019321f, 0.9657842847f, 0.971543554f, 0.9772799235f, 0.9829935747f,
    0.9886846868f, 0.9943534369f
};
static const float kLog2Slope[128] = {
    0.01122725542f, 0.01114055761f, 0.01105518851f, 0.01097111782f, 0.01088831614f, 0.01080675496f,
    0.01072640659f, 0.0106472442f, 0.01056924171f, 0.01049237382f, 0.01041661595f, 0.01034194422f,
    0.01026833545f, 0.01019576711f, 0.01012421727f, 0.01005366466f, 0.009984088573f, 0.009915468865f,
    0.009847785956f, 0.009781020793f, 0.009715154833f, 0.009650170034f, 0.009586048829f, 0.009522774119f,
    0.009460329249f, 0.009398698002f, 0.009337864579f, 0.009277813588f, 0.009218530029f, 0.009159999285f,
    0.009102207107f, 0.009045139603f, 0.008988783227f, 0.00893312477f, 0.008878151346f, 0.008823850387f,
    0.008770209628f, 0.008717217101f, 0.008664861127f, 0.008613130305f, 0.008562013503f, 0.008511499856f,
    0.008461578748f, 0.008412239816f, 0.008363472935f, 0.008315268212f, 0.008267615984f, 0.008220506805f,
    0.008173931446f, 0.008127880883f, 0.008082346298f, 0.008037319065f, 0.007992790754f, 0.007948753115f,
    0.007905198085f, 0.007862117773f, 0.007819504459f, 0.007777350592f, 0.00773564878f, 0.00769439179f,
    0.007653572543f, 0.00761318411f, 0.007573219705f, 0.007533672685f, 0.007494536547f, 0.007455804919f,
    0.007417471562f, 0.007379530366f, 0.007341975341f, 0.007304800623f, 0.007268000464f, 0.007231569231f,
    0.007195501404f, 0.007159791573f, 0.007124434433f, 0.007089424786f, 0.007054757534f, 0.007020427678f,
    0.006986430316f, 0.006952760642f, 0.00691941394f, 0.006886385585f, 0.006853671041f, 0.006821265856f,
    0.006789165663f, 0.006757366175f, 0.006725863188f, 0.006694652574f, 0.006663730281f, 0.006633092332f,
    0.006602734824f, 0.006572653923f, 0.006542845867f, 0.006513306959f, 0.00648403357f, 0.006455022137f,
    0.006426269159f, 0.006397771198f, 0.006369524876f, 0.006341526874f, 0.006313773932f, 0.006286262847f,
    0.006258990472f, 0.006231953712f, 0.006205149527f, 0.006178574929f, 0.006152226982f, 0.006126102797f,
    0.006100199536f, 0.00607451441f, 0.006049044673f, 0.006023787628f, 0.005998740621f, 0.005973901045f,
    0.005949266331f, 0.005924833957f, 0.00590060144f, 0.005876566337f, 0.005852726245f, 0.005829078802f,
    0.005805621681f, 0.005782352594f, 0.005759269289f, 0.005736369549f, 0.005713651194f, 0.005691112078f,
    0.005668750087f, 0.005646563141f
};


static float fit_log(float positive_normal) {
#pragma HLS INLINE
    union { float f; uint32_t u; } cv;
    cv.f = positive_normal;
    const uint32_t bits = cv.u;
    const int exponent = (int)((bits >> 23) & 255U) - 127;
    const uint32_t fraction = bits & 0x7fffffU;
    const uint32_t segment = fraction >> 16;
    const float alpha = (float)(fraction & 0xffffU) * (1.0f / 65536.0f);
    return (float)exponent + kLog2Base[segment] + kLog2Slope[segment] * alpha;
}
#else
#error "GAUSS_LOG_IMPL must be 0 (V3) or 1 (V5)"
#endif
#else
static float fit_log(float positive_normal) {
#pragma HLS INLINE
    return logf(positive_normal);
}
#endif

// Streaming smoothing. Store only ONE full-spectrum buffer.
// One pass across the input AXIS frame. Boundary samples remain unfiltered,
// identical to the old five-point SG boundary policy. For the default
// 3-tap [1,2,1]/4 filter the gain is 1 and the weights are symmetric.
static float acquire_and_smooth(
    hls::stream<axis_t> &s_axis, float smoothed[MAX_SPECTRUM_LEN], int len
) {
    float global_max=0.0f;
#if GAUSS_FILTER_MODE == 0
    // Reference filter: 5-tap Savitzky-Golay, for A/B resource/accuracy testing.
    float r0=0.0f, r1=0.0f, r2=0.0f, r3=0.0f, r4=0.0f;
    acquire_loop: for (int i=0; i<len; ++i) {
#pragma HLS PIPELINE II=1
        axis_t rx=s_axis.read();
        union { uint32_t u; float f; } cv;
        cv.u=(uint32_t)rx.data;
        const float v=cv.f;
        r0=r1; r1=r2; r2=r3; r3=r4; r4=v;
        if (i < 2) {
            smoothed[i]=v;
            if (v > global_max) global_max=v;
        }
        if (i >= 4) {
            const float s=(12.0f/35.0f)*(r1+r3)
                         +(17.0f/35.0f)*r2
                         -(3.0f/35.0f)*(r0+r4);
            smoothed[i-2]=s;
            if (s > global_max) global_max=s;
        }
    }
    if (len >= 3) {
        smoothed[len-2]=r3;
        smoothed[len-1]=r4;
        if (r3 > global_max) global_max=r3;
        if (r4 > global_max) global_max=r4;
    }
#elif GAUSS_FILTER_MODE == 1
    // [1,2,1]/4: only two powers-of-two constant multiplies and two sums
    // per interior sample, versus the original SG's three multiplies.
    // Output for sample (i-1) is written when input sample i is received.
    float left=0.0f, center=0.0f;
    acquire_loop: for (int i=0; i<len; ++i) {
#pragma HLS PIPELINE II=1
        axis_t rx=s_axis.read();
        union { uint32_t u; float f; } cv;
        cv.u=(uint32_t)rx.data;
        const float right=cv.f;
        if (i==0) {
            smoothed[0]=right;
            if (right > global_max) global_max=right;
        } else if (i>=2) {
            // Symmetry + binary fractions help Vivado HLS simplify hardware.
            const float s=(left+right)*0.25f + center*0.5f;
            smoothed[i-1]=s;
            if (s > global_max) global_max=s;
        }
        left=center;
        center=right;
    }
    if (len>=2) {
        smoothed[len-1]=center;
        if (center>global_max) global_max=center;
    }
#elif GAUSS_FILTER_MODE == 2
    // Direct pass through for no-filter reference; same output protocol.
    acquire_loop: for (int i=0; i<len; ++i) {
#pragma HLS PIPELINE II=1
        axis_t rx=s_axis.read();
        union { uint32_t u; float f; } cv;
        cv.u=(uint32_t)rx.data;
        smoothed[i]=cv.f;
        if (cv.f>global_max) global_max=cv.f;
    }
#else
#error "GAUSS_FILTER_MODE supports only 0=SG5, 1=binomial3, 2=bypass"
#endif
    return global_max;
}

static int detect_global_peaks(
    const float smoothed[MAX_SPECTRUM_LEN], int len,
    int peak_pos[MAX_DETECT_PEAKS], float peak_val[MAX_DETECT_PEAKS],
    int max_peaks, float threshold, int min_peak_distance
) {
    int count = 0;
    float left=0.0f, mid=0.0f;
    // 1 memory read/cycle, rather than 3 random memory reads/cycle.
    detect_loop: for (int i = 0; i < len; i++) {
#pragma HLS PIPELINE II=1
        const float right = smoothed[i];
        if (i >= 2) {
            const int idx = i - 1;
            if (mid > threshold && mid >= left && mid >= right) {
                if (count > 0 && idx - peak_pos[count-1] < min_peak_distance) {
                    if (mid > peak_val[count-1]) {
                        peak_pos[count-1] = idx;
                        peak_val[count-1] = mid;
                    }
                } else if (count < max_peaks) {
                    peak_pos[count] = idx;
                    peak_val[count] = mid;
                    ++count;
                } else {
                    break;
                }
            }
        }
        left = mid;
        mid = right;
    }
    return count;
}

static float fallback_centroid(
    const float smoothed[MAX_SPECTRUM_LEN], int len, int pk
) {
    float sum_weight=0.0f, sum_offset=0.0f;
    centroid: for (int d = -3; d <= 3; ++d) {
#pragma HLS PIPELINE
        const int i = pk + d;
        if (i >= 0 && i < len) {
            const float v = smoothed[i];
            if (v > 0.0f) {
                sum_weight += v;
                sum_offset += (float)d * v;
            }
        }
    }
    if (sum_weight > 1e-6f) return sum_offset / sum_weight;
    if (pk <= 0 || pk >= len-1) return 0.0f;
    const float l = smoothed[pk-1], c = smoothed[pk], r = smoothed[pk+1];
    const float denom = 2.0f * (l + r - 2.0f*c);
    return (fabsf(denom) < 1e-9f) ? 0.0f : (l-r)/denom;
}

// Uniformly sampled Gaussian: y(k)=log(I(k)-baseline)=a*k^2+b*k+c.
// For symmetric integer k in [-h,h], sum(k)=sum(k^3)=0.
// This reduces the original 3x3 solver to three moment sums and ONE division.
static float gauss_fit_peak(
    const float smoothed[MAX_SPECTRUM_LEN], int len,
    int pk, float peak_value, int base_edge
) {
    const float half_height = peak_value * 0.5f;
    int left_idx=pk, right_idx=pk;
    find_left: for (int j=1; j<=MAX_FIT_HALF_WIDTH; ++j) {
#pragma HLS PIPELINE
        const int idx=pk-j;
        if (idx < 0 || smoothed[idx] < half_height) break;
        left_idx=idx;
    }
    find_right: for (int j=1; j<=MAX_FIT_HALF_WIDTH; ++j) {
#pragma HLS PIPELINE
        const int idx=pk+j;
        if (idx >= len || smoothed[idx] < half_height) break;
        right_idx=idx;
    }

    int h=(right_idx-left_idx)/2;
    if (h < 3) h=3;
    // The moment simplification requires an EXACTLY symmetric window.
    if (h > pk) h=pk;
    if (h > len-1-pk) h=len-1-pk;
    if (h < 3) return fallback_centroid(smoothed,len,pk);

    // Bounded baseline scans; behavior matches the valid indices in original loops.
    const int fit_left=pk-h, fit_right=pk+h;
    const int left_count = (base_edge < fit_left) ? base_edge : fit_left;
    const int right_available = len-1-fit_right;
    const int right_count = (base_edge < right_available) ? base_edge : right_available;
    float sum_baseline=0.0f;
    baseline_left: for (int i=fit_left-left_count; i<fit_left; ++i) {
#pragma HLS PIPELINE
        sum_baseline += smoothed[i];
    }
    baseline_right: for (int i=fit_right+1; i<=fit_right+right_count; ++i) {
#pragma HLS PIPELINE
        sum_baseline += smoothed[i];
    }
    const int baseline_count=left_count+right_count;
    const float baseline = (baseline_count > 0) ?
        sum_baseline / (float)baseline_count : 0.0f;

    float s0=0.0f, s1=0.0f, s2=0.0f;
    fit_moments: for (int k=-h; k<=h; ++k) {
        const float subtract=smoothed[pk+k]-baseline;
        const float safe=(subtract > 1e-9f) ? subtract : 1e-9f;
        const float y=fit_log(safe);
        const float kf=(float)k;
        s0 += y;
        s1 += kf*y;
        s2 += (kf*kf)*y;
    }
    // Direct symmetric quadratic least-squares solution; no 3x3 matrix.
    // Let n=2*h+1, M2=sum(k*k) and y=log2(I-baseline).
    // For [-h,h], delta=-[n*(4*h*(h+1)-3)/30]*s1/(n*s2-M2*s0).
    // Compute coefficients from h instead of allocating extra constant ROMs.
    const float hf=(float)h;
    const float n=2.0f*hf+1.0f;
    const float hprod=hf*(hf+1.0f);
    const float m2=(n*hprod)*(1.0f/3.0f);
    const float vertex_factor=(n*(4.0f*hprod-3.0f))*(1.0f/30.0f);
    const float denom=n*s2-m2*s0;
    if (denom >= -1e-7f) return fallback_centroid(smoothed,len,pk);
    const float delta=(-vertex_factor*s1)/denom;
    if (!(delta >= -hf && delta <= hf)) {
        return fallback_centroid(smoothed,len,pk);
    }
    return delta;
}

void gauss_fit_demod_multi(
    hls::stream<axis_t> &s_axis, hls::stream<axis_t> &m_axis,
    float lambda_start, float lambda_step, uint32_t data_len,
    uint32_t max_peaks, float thresh_ratio, uint32_t min_peak_distance,
    uint32_t base_edge
) {
#pragma HLS INTERFACE axis port=s_axis
#pragma HLS INTERFACE axis port=m_axis
#pragma HLS INTERFACE s_axilite port=lambda_start
#pragma HLS INTERFACE s_axilite port=lambda_step
#pragma HLS INTERFACE s_axilite port=data_len
#pragma HLS INTERFACE s_axilite port=max_peaks
#pragma HLS INTERFACE s_axilite port=thresh_ratio
#pragma HLS INTERFACE s_axilite port=min_peak_distance
#pragma HLS INTERFACE s_axilite port=base_edge
#pragma HLS INTERFACE s_axilite port=return
#pragma HLS INLINE off

    if (data_len > MAX_SPECTRUM_LEN) data_len=MAX_SPECTRUM_LEN;
    if (max_peaks > MAX_DETECT_PEAKS) max_peaks=MAX_DETECT_PEAKS;
    if (min_peak_distance < 1) min_peak_distance=1;
    if (base_edge > data_len) base_edge=data_len;

    float smoothed[MAX_SPECTRUM_LEN];
#if GAUSS_LEGACY_HLS
#pragma HLS RESOURCE variable=smoothed core=RAM_1P
#else
#pragma HLS bind_storage variable=smoothed type=ram_1p impl=bram
#endif
    const float global_max=acquire_and_smooth(s_axis,smoothed,(int)data_len);

    int detect_pos[MAX_DETECT_PEAKS];
    float detect_val[MAX_DETECT_PEAKS];
    const int detected=detect_global_peaks(
        smoothed,(int)data_len,detect_pos,detect_val,(int)max_peaks,
        global_max*thresh_ratio,(int)min_peak_distance);

    float wavelengths[MAX_DETECT_PEAKS];
    int indices[MAX_DETECT_PEAKS];
    int valid=0;
    process_peaks: for (int p=0; p<detected; ++p) {
        // The intervals partition the spectrum. Combine old max and mean scans.
        int start=(p==0) ? 0 : (detect_pos[p-1]+detect_pos[p])/2;
        int end=(p==detected-1) ? (int)data_len-1 :
            (detect_pos[p]+detect_pos[p+1])/2;
        float mx=-1e9f, sum=0.0f;
        int pk=-1;
        check_window: for (int i=start; i<=end; ++i) {
#pragma HLS PIPELINE
            const float v=smoothed[i];
            sum+=v;
            if (v>mx) { mx=v; pk=i; }
        }
        if (pk<0 || mx<=0.0f) continue;
        // Compare without a floating divider: mx >= 1.3*sum/count.
        const float scaled_peak=mx*(float)(end-start+1);
        if (scaled_peak<1.3f*sum || mx<5.0f) continue;

        const float delta=gauss_fit_peak(smoothed,(int)data_len,pk,mx,(int)base_edge);
        const float pixel=(float)pk+delta;
        indices[valid]=(int)(pixel+0.5f);
        wavelengths[valid]=lambda_start+pixel*lambda_step;
        ++valid;
    }

    // Keep AXIS output ordering without peak-loop unrolling.
    sort_outer: for (int i=1; i<valid; ++i) {
        const int ip=indices[i];
        const float wp=wavelengths[i];
        int j=i;
        sort_inner: while (j>0 && indices[j-1]>ip) {
            indices[j]=indices[j-1];
            wavelengths[j]=wavelengths[j-1];
            --j;
        }
        indices[j]=ip;
        wavelengths[j]=wp;
    }

    axis_t tx;
    union { uint32_t u; float f; } cv;
    cv.f=(float)valid;
    tx.data=cv.u;
    tx.keep=0xF; tx.strb=0xF;
    tx.last=(valid==0) ? 1 : 0;
    m_axis.write(tx);
    send_peaks: for (int i=0; i<2*valid; ++i) {
#pragma HLS PIPELINE II=1
        const int p=i>>1;
        cv.f=((i & 1) == 0) ? (float)indices[p] : wavelengths[p];
        tx.data=cv.u;
        tx.last=(i==2*valid-1) ? 1 : 0;
        m_axis.write(tx);
    }
}
