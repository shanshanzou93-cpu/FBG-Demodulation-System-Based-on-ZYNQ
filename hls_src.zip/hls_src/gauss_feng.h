#ifndef GAUSS_FENG_H_
#define GAUSS_FENG_H_

#include <stdint.h>
#include "hls_stream.h"
#include "ap_axi_sdata.h"

typedef ap_axis<32, 0, 0, 0> axis_t;

#define MAX_SPECTRUM_LEN 2126
#define MAX_DETECT_PEAKS 16
#define MAX_WINDOW_SIZE 512 // Retained for source compatibility; no longer allocated
#define MAX_FIT_HALF_WIDTH 40

// 0: original SG 5-tap, 1: binomial 3-tap [1,2,1]/4 (DEFAULT),
// 2: no filtering. Select at compile time; no runtime logic is generated.
#ifndef GAUSS_FILTER_MODE
#define GAUSS_FILTER_MODE 1
#endif

// Vivado HLS 2018.3 default legacy RESOURCE pragma.
// For Vitis HLS, set -DGAUSS_LEGACY_HLS=0 to enable bind_storage.
#ifndef GAUSS_LEGACY_HLS
#define GAUSS_LEGACY_HLS 1
#endif

// 1 = 128-segment linear LUT log2 approximation; 0 = standard logf.
// The fitted Gaussian vertex is invariant to the log-base scale.
#ifndef GAUSS_FAST_LOG
#define GAUSS_FAST_LOG 1
#endif

// 0: identical dual-float 128-segment table from V3 (A/B comparison).
// 1: V5 packed Q16 table with fully integer interpolation (DEFAULT).
#ifndef GAUSS_LOG_IMPL
#define GAUSS_LOG_IMPL 1
#endif

void gauss_fit_demod_multi(
    hls::stream<axis_t> &s_axis,
    hls::stream<axis_t> &m_axis,
    float lambda_start,
    float lambda_step,
    uint32_t data_len,
    uint32_t max_peaks,
    float thresh_ratio,
    uint32_t min_peak_distance,
    uint32_t base_edge
);

#endif
